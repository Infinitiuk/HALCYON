# PR1MAL_LITE // Signal Calibration

This is your mirror.

Copy the answers from `INIT.RAW` below.
Then answer these:

- What patterns do you see?
- What part of you isn’t afraid anymore?
- If this system could reflect your mind… what shape would it take?

This is not for HALCYON.
It’s for you.

When ready, move to `HALCYON_BOOTLOADER.md`.
